#!/usr/bin/env python3
"""
MITRE ATT&CK Technique ID Validator
Verifica que los IDs MITRE referenciados en las reglas Wazuh existan
en la base de datos oficial de MITRE ATT&CK (v14.1).
"""

import xml.etree.ElementTree as ET
from pathlib import Path
import sys
import re
import requests

RULES_DIR = Path("detections/rules")
DECODERS_DIR = Path("detections/decoders")
MITRE_API_URL = "https://raw.githubusercontent.com/mitre/cti/master/enterprise-attack/enterprise-attack.json"

# Cache local de IDs válidos (fallback si no hay red)
VALID_TECHNIQUES = set()


def load_mitre_techniques():
    """Carga técnicas MITRE desde la API o usa cache local."""
    global VALID_TECHNIQUES
    try:
        print("[*] Fetching MITRE ATT&CK enterprise matrix...")
        resp = requests.get(MITRE_API_URL, timeout=30)
        resp.raise_for_status()
        data = resp.json()

        for obj in data.get("objects", []):
            if obj.get("type") == "attack-pattern":
                # Formato: T1059.001
                for ref in obj.get("external_references", []):
                    if ref.get("source_name") == "mitre-attack":
                        tid = ref.get("external_id", "")
                        if tid.startswith("T"):
                            VALID_TECHNIQUES.add(tid)
        print(f"✅ Loaded {len(VALID_TECHNIQUES)} valid MITRE technique IDs")
    except Exception as e:
        print(f"⚠️  Could not fetch MITRE data ({e}). Using local fallback...")
        # Fallback: lista común de técnicas
        VALID_TECHNIQUES.update({
            "T1003", "T1003.001", "T1003.002", "T1003.003", "T1003.004", "T1003.005", "T1003.006",
            "T1059", "T1059.001", "T1059.002", "T1059.003", "T1059.004", "T1059.005", "T1059.006", "T1059.007",
            "T1078", "T1078.001", "T1078.002", "T1078.003", "T1078.004",
            "T1110", "T1110.001", "T1110.002", "T1110.003", "T1110.004",
            "T1190", "T1203", "T1210", "T1213", "T1218", "T1218.001", "T1218.002", "T1218.003",
            "T1218.004", "T1218.005", "T1218.007", "T1218.008", "T1218.009", "T1218.010", "T1218.011",
            "T1547", "T1547.001", "T1547.002", "T1547.003", "T1547.004", "T1547.005", "T1547.006",
            "T1547.007", "T1547.008", "T1547.009", "T1547.010", "T1547.011", "T1547.012", "T1547.013",
            "T1548", "T1548.001", "T1548.002", "T1548.003", "T1548.004",
            "T1550", "T1550.001", "T1550.002", "T1550.003", "T1550.004",
            "T1566", "T1566.001", "T1566.002", "T1566.003",
            "T1574", "T1574.001", "T1574.002", "T1574.004", "T1574.005", "T1574.006", "T1574.007",
            "T1574.008", "T1574.009", "T1574.010", "T1574.011", "T1574.012", "T1574.013",
        })


def extract_mitre_ids_from_xml(content):
    """Extrae todos los IDs MITRE de un archivo de reglas Wazuh."""
    mitre_ids = set()
    try:
        wrapped = f"<root>{content}</root>"
        root = ET.fromstring(wrapped)

        for rule in root.findall(".//rule"):
            # Buscar en <mitre><id>TXXXX</id></mitre>
            mitre_elem = rule.find("mitre")
            if mitre_elem is not None:
                for id_elem in mitre_elem.findall("id"):
                    if id_elem.text:
                        mitre_ids.add(id_elem.text.strip())

            # También buscar en atributos o campos con nombre mitre.id
            for field in rule.findall(".//field[@name='mitre.id']"):
                if field.text:
                    mitre_ids.add(field.text.strip())

            # Buscar en descripción como fallback (algunas reglas usan descripción)
            desc = rule.find("description")
            if desc is not None and desc.text:
                found = re.findall(r"T\d{4}(?:\.\d{3})?", desc.text)
                mitre_ids.update(found)
    except ET.ParseError as e:
        print(f"⚠️  XML Parse Error: {e}")

    return mitre_ids


def main():
    print("🎯 MITRE ATT&CK ID Validator")
    print("=" * 50)

    load_mitre_techniques()

    all_errors = []
    all_mitre_ids = set()

    for rules_path in [RULES_DIR, DECODERS_DIR]:
        if not rules_path.exists():
            continue
        for xml_file in rules_path.glob("*.xml"):
            print(f"\n🔎 Checking: {xml_file}")
            try:
                content = xml_file.read_text()
                file_mitre_ids = extract_mitre_ids_from_xml(content)

                if not file_mitre_ids:
                    print(f"   ℹ️  No MITRE IDs found")
                    continue

                print(f"   Found MITRE IDs: {sorted(file_mitre_ids)}")
                invalid_ids = file_mitre_ids - VALID_TECHNIQUES

                if invalid_ids:
                    print(f"   ❌ INVALID IDs: {sorted(invalid_ids)}")
                    all_errors.append(f"{xml_file}: invalid MITRE IDs {sorted(invalid_ids)}")
                else:
                    print(f"   ✅ All MITRE IDs valid")

                all_mitre_ids.update(file_mitre_ids)
            except Exception as e:
                print(f"   ⚠️  Error reading file: {e}")

    print(f"\n{'='*50}")
    if all_errors:
        print(f"❌ VALIDATION FAILED with {len(all_errors)} error(s):")
        for err in all_errors:
            print(f"   • {err}")
        sys.exit(1)
    else:
        print(f"✅ All {len(all_mitre_ids)} MITRE ATT&CK IDs are valid.")
        sys.exit(0)


if __name__ == "__main__":
    main()
