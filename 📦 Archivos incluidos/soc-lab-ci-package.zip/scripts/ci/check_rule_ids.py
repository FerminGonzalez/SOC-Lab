#!/usr/bin/env python3
"""
Wazuh Rule ID Conflict Checker
Adaptado del script oficial de Wazuh Ruleset as Code (RaC)
Verifica que no existan IDs de reglas duplicados entre archivos XML custom.
Rango permitido para reglas custom: 100000 - 120000
"""

import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path
import sys
from collections import defaultdict, Counter

RULES_DIR = Path("detections/rules")
DECODERS_DIR = Path("detections/decoders")
CUSTOM_ID_MIN = 100000
CUSTOM_ID_MAX = 120000


def run_git_command(args):
    result = subprocess.run(args, capture_output=True, text=True, check=True)
    return result.stdout


def get_changed_rule_files():
    """Obtiene archivos XML modificados en el push/PR actual."""
    try:
        # Detectar si estamos en un PR o en un push
        # En PR: comparamos contra origin/main
        # En push: comparamos HEAD~1 contra HEAD
        output = run_git_command(["git", "diff", "--name-status", "HEAD~1", "HEAD"])
        changed_files = []
        for line in output.strip().splitlines():
            parts = line.strip().split(maxsplit=1)
            if len(parts) != 2:
                continue
            status, file_path = parts
            if file_path.endswith(".xml") and (
                file_path.startswith(str(RULES_DIR)) or 
                file_path.startswith(str(DECODERS_DIR))
            ):
                changed_files.append((status, Path(file_path)))
        return changed_files
    except subprocess.CalledProcessError:
        # Si no hay historial suficiente, analizamos todos los archivos
        return [("A", p) for p in RULES_DIR.glob("*.xml")]


def extract_rule_ids_from_xml(content):
    """Extrae IDs de reglas de contenido XML (soporta múltiples roots)."""
    ids = []
    try:
        # Wazuh permite múltiples elementos root sin <group> wrapper en algunos casos
        wrapped = f"<root>{content}</root>"
        root = ET.fromstring(wrapped)
        for rule in root.findall(".//rule"):
            rule_id = rule.get("id")
            if rule_id and rule_id.isdigit():
                ids.append(int(rule_id))
    except ET.ParseError as e:
        print(f"⚠️  XML Parse Error: {e}")
    return ids


def get_all_rule_ids_in_repo():
    """Obtiene todos los IDs de reglas existentes en el repositorio."""
    rule_id_to_files = defaultdict(set)

    for rules_path in [RULES_DIR, DECODERS_DIR]:
        if not rules_path.exists():
            continue
        for xml_file in rules_path.glob("*.xml"):
            try:
                content = xml_file.read_text()
                rule_ids = extract_rule_ids_from_xml(content)
                for rule_id in rule_ids:
                    rule_id_to_files[rule_id].add(str(xml_file))
            except Exception:
                continue
    return rule_id_to_files


def detect_duplicates(rule_ids):
    counter = Counter(rule_ids)
    return [rule_id for rule_id, count in counter.items() if count > 1]


def validate_custom_id_range(rule_ids):
    """Verifica que los IDs estén en el rango permitido para reglas custom."""
    out_of_range = [rid for rid in rule_ids if rid < CUSTOM_ID_MIN or rid > CUSTOM_ID_MAX]
    return out_of_range


def main():
    print("🔍 Wazuh Rule ID Conflict Checker")
    print("=" * 50)

    changed_files = get_changed_rule_files()
    if not changed_files:
        print("ℹ️  No rule/decoder files were changed in this commit.")
        # Aún así verificamos todo el repo por si acaso
        changed_files = [("A", p) for p in RULES_DIR.glob("*.xml")]

    all_repo_ids = get_all_rule_ids_in_repo()

    errors = []

    for status, path in changed_files:
        print(f"\n🔎 Checking file: {path}")

        try:
            content = path.read_text()
            dev_ids = extract_rule_ids_from_xml(content)
        except Exception as e:
            print(f"⚠️  Could not read {path}: {e}")
            continue

        if not dev_ids:
            print(f"ℹ️  No rule IDs found in {path.name}")
            continue

        # 1. Verificar duplicados internos en el archivo
        duplicates = detect_duplicates(dev_ids)
        if duplicates:
            print(f"❌ Duplicate rule IDs detected IN FILE {path.name}: {sorted(duplicates)}")
            errors.append(f"Internal duplicates in {path.name}: {duplicates}")

        # 2. Verificar rango custom
        out_of_range = validate_custom_id_range(dev_ids)
        if out_of_range:
            print(f"❌ Rule IDs OUT OF RANGE in {path.name}: {sorted(out_of_range)}")
            print(f"   Allowed range: {CUSTOM_ID_MIN}-{CUSTOM_ID_MAX}")
            errors.append(f"Out of range IDs in {path.name}: {out_of_range}")

        # 3. Verificar conflictos con otros archivos del repo
        conflicting_ids = set(dev_ids) & (set(all_repo_ids.keys()) - set(dev_ids))
        # Excluir IDs del propio archivo
        own_ids = set(dev_ids)
        other_files_ids = {k: v for k, v in all_repo_ids.items() if k not in own_ids}
        conflicts = set(dev_ids) & set(other_files_ids.keys())

        if conflicts:
            print(f"❌ CONFLICTS detected in {path.name}:")
            for rule_id in sorted(conflicts):
                files = other_files_ids.get(rule_id, [])
                print(f"   Rule ID {rule_id} already exists in: {', '.join(files)}")
            errors.append(f"ID conflicts in {path.name}: {sorted(conflicts)}")
        else:
            print(f"✅ No conflicts in {path.name}")

    # Verificación global: duplicados entre TODOS los archivos
    print("\n🔎 Global duplicate check across all rule files...")
    all_ids = []
    for rid, files in all_repo_ids.items():
        if len(files) > 1:
            print(f"❌ Rule ID {rid} exists in multiple files: {', '.join(files)}")
            errors.append(f"Global duplicate: {rid} in {files}")

    if errors:
        print(f"\n❌ VALIDATION FAILED with {len(errors)} error(s).")
        sys.exit(1)
    else:
        print("\n✅ All rule ID checks passed.")
        sys.exit(0)


if __name__ == "__main__":
    main()
