#!/usr/bin/env python3
"""
Wazuh Ruleset Quality Linter
Verifica buenas prácticas de redacción de reglas:
  - Descripciones no vacías y con longitud adecuada
  - Levels dentro de rangos razonables (0-16)
  - Grupos bien definidos
  - Reglas sin <mitre> mapping (warning)
  - Reglas con <field> vacíos (error)
  - Uso de <if_sid> sin referencia circular
"""

import xml.etree.ElementTree as ET
from pathlib import Path
import sys

RULES_DIR = Path("detections/rules")
DECODERS_DIR = Path("detections/decoders")

QUALITY_ISSUES = []


def add_issue(severity: str, file: Path, rule_id: str, message: str):
    QUALITY_ISSUES.append({
        "severity": severity,
        "file": str(file),
        "rule_id": rule_id,
        "message": message
    })


def check_rule_quality(xml_file: Path):
    """Analiza calidad de reglas en un archivo XML."""
    try:
        content = xml_file.read_text()
        wrapped = f"<root>{content}</root>"
        root = ET.fromstring(wrapped)
    except ET.ParseError as e:
        add_issue("ERROR", xml_file, "N/A", f"XML parse error: {e}")
        return

    for rule in root.findall(".//rule"):
        rule_id = rule.get("id", "UNKNOWN")
        level = rule.get("level", "0")

        # 1. Verificar descripción
        desc = rule.find("description")
        if desc is None or not desc.text or not desc.text.strip():
            add_issue("ERROR", xml_file, rule_id, "Rule has no description")
        elif len(desc.text.strip()) < 10:
            add_issue("WARNING", xml_file, rule_id, f"Description too short: '{desc.text}'")

        # 2. Verificar level
        try:
            lvl = int(level)
            if lvl < 0 or lvl > 16:
                add_issue("ERROR", xml_file, rule_id, f"Invalid level: {lvl} (must be 0-16)")
            elif lvl == 0 and not any(rule.findall(".//if_sid")):
                # Level 0 sin if_sid es sospechoso (regla base que no genera alerta)
                pass  # Podría ser intencional
        except ValueError:
            add_issue("ERROR", xml_file, rule_id, f"Level is not a number: {level}")

        # 3. Verificar grupos
        groups = rule.get("group", "")
        if not groups:
            add_issue("WARNING", xml_file, rule_id, "Rule has no group attribute")

        # 4. Verificar MITRE mapping
        mitre = rule.find("mitre")
        if mitre is None:
            add_issue("WARNING", xml_file, rule_id, "Rule lacks MITRE ATT&CK mapping")
        else:
            mitre_ids = mitre.findall("id")
            if not mitre_ids:
                add_issue("WARNING", xml_file, rule_id, "MITRE block exists but has no technique IDs")

        # 5. Verificar campos vacíos
        for field in rule.findall("field"):
            if not field.text or not field.text.strip():
                add_issue("ERROR", xml_file, rule_id, f"Empty field: name={field.get('name', 'unknown')}")

        # 6. Verificar match/regex vacíos
        for tag in ["match", "regex"]:
            elem = rule.find(tag)
            if elem is not None and (not elem.text or not elem.text.strip()):
                add_issue("ERROR", xml_file, rule_id, f"Empty <{tag}> element")

        # 7. Verificar if_sid circular (básico: si_sid que se refiere a sí mismo)
        if_sid = rule.find("if_sid")
        if if_sid is not None and if_sid.text:
            if rule_id in if_sid.text.split(","):
                add_issue("ERROR", xml_file, rule_id, "Circular if_sid reference (references itself)")


def main():
    print("🏆 Wazuh Ruleset Quality Linter")
    print("=" * 60)

    files_checked = 0
    for rules_path in [RULES_DIR, DECODERS_DIR]:
        if not rules_path.exists():
            continue
        for xml_file in rules_path.glob("*.xml"):
            print(f"🔎 Checking: {xml_file}")
            check_rule_quality(xml_file)
            files_checked += 1

    print(f"\n{'='*60}")
    print(f"📊 Checked {files_checked} file(s)")

    if not QUALITY_ISSUES:
        print("✅ No quality issues found. Ruleset meets all quality gates.")
        sys.exit(0)

    errors = [i for i in QUALITY_ISSUES if i["severity"] == "ERROR"]
    warnings = [i for i in QUALITY_ISSUES if i["severity"] == "WARNING"]

    print(f"\n❌ Errors: {len(errors)} | ⚠️  Warnings: {len(warnings)}")
    print("-" * 60)

    for issue in QUALITY_ISSUES:
        icon = "❌" if issue["severity"] == "ERROR" else "⚠️"
        print(f"{icon} [{issue['file']}] Rule {issue['rule_id']}: {issue['message']}")

    if errors:
        print(f"\n❌ VALIDATION FAILED: {len(errors)} error(s) must be fixed.")
        sys.exit(1)
    else:
        print(f"\n✅ No errors. {len(warnings)} warning(s) to review.")
        sys.exit(0)


if __name__ == "__main__":
    main()
