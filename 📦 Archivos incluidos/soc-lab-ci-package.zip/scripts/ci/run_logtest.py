#!/usr/bin/env python3
"""
Wazuh Functional Test Runner
Ejecuta wazuh-logtest dentro de un contenedor Docker de Wazuh Manager
y verifica que las reglas custom se activen correctamente contra logs de ejemplo.

Requiere:
  - Contenedor 'wazuh-manager' corriendo con wazuh-analysisd activo
  - Archivo tests/test_cases.json con los casos de prueba
"""

import json
import subprocess
import sys
import re
from pathlib import Path

TEST_CASES_FILE = Path("tests/test_cases.json")
RESULTS_DIR = Path("tests/results")
CONTAINER_NAME = "wazuh-manager"
LOGTEST_BIN = "/var/ossec/bin/wazuh-logtest"


def run_logtest(log_line: str) -> str:
    """Ejecuta wazuh-logtest con un log de prueba y retorna la salida cruda."""
    try:
        # wazuh-logtest es interactivo; le pasamos el log por stdin y capturamos stdout
        proc = subprocess.run(
            ["docker", "exec", "-i", CONTAINER_NAME, LOGTEST_BIN, "-q"],
            input=log_line + "\n",
            capture_output=True,
            text=True,
            timeout=30
        )
        return proc.stdout + proc.stderr
    except subprocess.TimeoutExpired:
        return "TIMEOUT"
    except Exception as e:
        return f"ERROR: {e}"


def parse_logtest_output(output: str) -> dict:
    """Extrae información clave de la salida de wazuh-logtest."""
    result = {
        "matched_rule_id": None,
        "matched_rule_level": None,
        "matched_rule_desc": None,
        "decoder": None,
        "alert_generated": False,
        "raw_output": output
    }

    # Extraer Rule ID
    id_match = re.search(r"id:\s*'(\d+)'", output)
    if id_match:
        result["matched_rule_id"] = id_match.group(1)

    # Extraer Level
    level_match = re.search(r"level:\s*'(\d+)'", output)
    if level_match:
        result["matched_rule_level"] = int(level_match.group(1))

    # Extraer Description
    desc_match = re.search(r"description:\s*'([^']+)'", output)
    if desc_match:
        result["matched_rule_desc"] = desc_match.group(1)

    # Extraer Decoder
    decoder_match = re.search(r"name:\s*'([^']+)'", output)
    if decoder_match:
        result["decoder"] = decoder_match.group(1)

    # ¿Se generó alerta?
    if "Alert to be generated" in output or "**Alert to be generated" in output:
        result["alert_generated"] = True

    return result


def load_test_cases() -> list:
    """Carga los casos de prueba desde JSON."""
    if not TEST_CASES_FILE.exists():
        print(f"❌ Test cases file not found: {TEST_CASES_FILE}")
        sys.exit(1)

    with open(TEST_CASES_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def main():
    print("🧪 Wazuh Functional Test Runner")
    print("=" * 60)

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    test_cases = load_test_cases()

    passed = 0
    failed = 0
    results = []

    for case in test_cases:
        name = case["name"]
        log_file = Path(case["log_file"])
        expected_rule_id = str(case.get("expected_rule_id", ""))
        expected_level = case.get("expected_level")
        expected_alert = case.get("expected_alert", True)

        print(f"\n🔎 Test: {name}")
        print(f"   Log file: {log_file}")

        if not log_file.exists():
            print(f"   ❌ LOG FILE NOT FOUND: {log_file}")
            failed += 1
            results.append({"test": name, "status": "FAILED", "reason": "log file missing"})
            continue

        log_line = log_file.read_text().strip()
        if not log_line:
            print(f"   ❌ LOG FILE EMPTY: {log_file}")
            failed += 1
            results.append({"test": name, "status": "FAILED", "reason": "log empty"})
            continue

        print(f"   Log: {log_line[:100]}...")

        output = run_logtest(log_line)
        parsed = parse_logtest_output(output)

        errors = []

        # Verificar rule ID
        if expected_rule_id and parsed["matched_rule_id"] != expected_rule_id:
            errors.append(
                f"Rule ID mismatch: expected {expected_rule_id}, got {parsed['matched_rule_id']}"
            )

        # Verificar level
        if expected_level is not None and parsed["matched_rule_level"] != expected_level:
            errors.append(
                f"Level mismatch: expected {expected_level}, got {parsed['matched_rule_level']}"
            )

        # Verificar alerta
        if expected_alert and not parsed["alert_generated"]:
            errors.append("Expected alert to be generated, but it was not")

        if errors:
            print(f"   ❌ FAILED:")
            for err in errors:
                print(f"      • {err}")
            failed += 1
            results.append({
                "test": name,
                "status": "FAILED",
                "errors": errors,
                "output": parsed
            })
        else:
            print(f"   ✅ PASSED")
            print(f"      Rule: {parsed['matched_rule_id']} | Level: {parsed['matched_rule_level']} | Alert: {parsed['alert_generated']}")
            passed += 1
            results.append({
                "test": name,
                "status": "PASSED",
                "output": parsed
            })

        # Guardar salida cruda para debugging
        raw_file = RESULTS_DIR / f"{name}_raw.txt"
        raw_file.write_text(output, encoding="utf-8")

    # Guardar reporte JSON
    report = {
        "summary": {
            "total": len(test_cases),
            "passed": passed,
            "failed": failed,
            "success_rate": round(passed / len(test_cases) * 100, 1) if test_cases else 0
        },
        "results": results
    }

    report_file = RESULTS_DIR / "test_report.json"
    with open(report_file, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print(f"\n{'='*60}")
    print(f"📊 RESULTS: {passed} passed, {failed} failed out of {len(test_cases)}")
    print(f"📄 Full report: {report_file}")

    if failed > 0:
        sys.exit(1)
    else:
        print("✅ All functional tests passed!")
        sys.exit(0)


if __name__ == "__main__":
    main()
