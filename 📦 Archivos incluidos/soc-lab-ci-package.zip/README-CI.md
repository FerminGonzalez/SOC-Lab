# Wazuh Ruleset CI/CD Pipeline

Pipeline de validación continua para reglas y decoders custom de Wazuh.

## Jobs incluidos

| Job | Descripción |
|-----|-------------|
| `xml-lint` | Valida sintaxis XML bien formada |
| `rule-id-conflicts` | Detecta IDs duplicados y fuera de rango (100000-120000) |
| `mitre-validation` | Verifica que los IDs MITRE ATT&CK existan en la matriz oficial |
| `wazuh-functional-test` | Levanta contenedor Wazuh Manager y ejecuta `wazuh-logtest` |
| `ruleset-quality` | Lint semántico: descripciones, levels, campos vacíos, etc. |

## Estructura

```
.github/workflows/validate-wazuh-rules.yml
scripts/ci/
  ├── check_rule_ids.py
  ├── validate_mitre.py
  ├── run_logtest.py
  └── ruleset_quality.py
tests/
  ├── test_cases.json
  └── logs/
      ├── mimikatz_sekurlsa.log
      ├── powershell_encoded.log
      └── lsass_access.log
detections/
  └── rules/
      ├── mimikatz-detection.xml
      ├── powershell-detection.xml
      └── lsass-access-detection.xml
```

## Uso

1. Copia `.github/workflows/` a tu repo
2. Copia `scripts/ci/`, `tests/` y `detections/` a tu repo
3. Ajusta las rutas en los scripts si tu estructura difiere
4. Haz push a `main` o `dev`, o abre un PR hacia `main`

## Agregar nuevos casos de prueba

Edita `tests/test_cases.json`:

```json
{
  "name": "nombre_del_test",
  "description": "Qué detecta",
  "log_file": "tests/logs/mi_log.log",
  "expected_rule_id": "100XXX",
  "expected_level": 10,
  "expected_alert": true,
  "mitre_technique": "TXXXX.XXX"
}
```

Crea el archivo de log en `tests/logs/mi_log.log` con UNA sola línea de log.
